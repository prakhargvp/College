-----------------------------------------------
GROUP DETAILS
-----------------------------------------------

NAME : PRAKHAR AGRAWAL
SEC  : CS & BDA
CLASS ROLL NO : 42
UNIVERSITY ROLL NO : 2010753
GROUP MEMBERS : 1 

-----------------------------------------------
PROJECT DETAILS
-----------------------------------------------

QUESTION ATTEMPT : 2,3
VALIDATION : DONE
COMMENTS   : DONE
MODULARITY : DONE
INDENTATION: DONE
-----------------------------------------------
COMPILE AND RUN DETAILS
-----------------------------------------------

LINUX/UBUNTU

step-1 : Open the terminal.
step-2 : Locate your C folder location.
step-3 : Compile your C file through compiler. Executable file generated.
step-4 : Execute your executable (obj) file.
step-5 : Enter details
step-6 : Check your generated output.
step-7 : Exit

~]$ ls
project
~]$ cd project
~]$ ls
code.c input.txt
~]$ gcc code.c -o project
~]$ ls
code.c project input.txt
~]$ ./project input.txt output.txt
~]$ ls
code.c project input.txt output.txt
~]$ cat output.txt
~]$

WINDOWS

1. Code Block IDE
Step-1 : Open the C file in Code Block.
step-2 : Build and Run Code (throught GUI or pressing F9), A Command prompt Opened.
step-3 : Enter the details in CMD.
step-4 : EXIT

2. CMD 
step-1 : Open the CMD and locate your C file folder.
step-2 : If you have already .exe file then enter .exe file name along with argument.
step-3 : ELSE compile throught compiler like gcc and then rum executable file.
step-4 : EXIT

